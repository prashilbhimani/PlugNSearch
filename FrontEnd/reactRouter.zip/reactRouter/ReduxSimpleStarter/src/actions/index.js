import axios from 'axios';
export const FETCH_POSTS = 'fetch_posts';
export const CREATE_POSTS = 'create_posts';
export const LOCAL_GET = 'local_get';

const ROOT_URL = 'http://reduxblog.herokuapp.com/api';
const API_KEY = '?key=paperbash1432;'


export function fetchPosts() {
  const request = axios.get(
    `${ROOT_URL}/posts${API_KEY}`,
    {
      timeout: 10000,
      withCredentials: true,
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    }
  );
  // console.log(`req: ${request}`)
  return {
    type: FETCH_POSTS,
    payload: request
  };
}

export function localGet() {
  const request = axios.get(
    'localhost:9000/foo',
    {
      timeout: 10000,
      withCredentials: true,
    }
  );
  return {
    type: LOCAL_GET,
    payload: request
  }
}

export function createPost(values) {
  const request = axios.post(`${ROOT_URL}/posts${API_KEY}`, values);

  return {
    type: CREATE_POST,
    payload: request
  }
}
